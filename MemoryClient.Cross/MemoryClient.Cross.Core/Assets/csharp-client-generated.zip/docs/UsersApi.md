# IO.Swagger.Api.UsersApi

All URIs are relative to *https://virtserver.swaggerhub.com/Project-Memory/MemoryApi/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AuthValidate**](UsersApi.md#authvalidate) | **POST** /auth/validate | valiates a user token


<a name="authvalidate"></a>
# **AuthValidate**
> string AuthValidate (string xAuthToken)

valiates a user token

Validates the authentication token in the header to establish access. Used internally and to validate token on client startup. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AuthValidateExample
    {
        public void main()
        {
            
            var apiInstance = new UsersApi();
            var xAuthToken = xAuthToken_example;  // string | Auth token to validate

            try
            {
                // valiates a user token
                string result = apiInstance.AuthValidate(xAuthToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UsersApi.AuthValidate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xAuthToken** | **string**| Auth token to validate | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

