# IO.Swagger.Api.AnonymousApi

All URIs are relative to *https://virtserver.swaggerhub.com/Project-Memory/MemoryApi/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AuthLogin**](AnonymousApi.md#authlogin) | **POST** /auth/login | attemps a log in with post body
[**AuthLoginProvider**](AnonymousApi.md#authloginprovider) | **POST** /auth/login-provider | attempts a log in with provider details in post body
[**UsersRegister**](AnonymousApi.md#usersregister) | **POST** /users/register | registers a user with the service


<a name="authlogin"></a>
# **AuthLogin**
> string AuthLogin (LoginModel body)

attemps a log in with post body

Validates the user credentials specified in the post body and generates a login session if correct. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AuthLoginExample
    {
        public void main()
        {
            
            var apiInstance = new AnonymousApi();
            var body = new LoginModel(); // LoginModel | Login form data

            try
            {
                // attemps a log in with post body
                string result = apiInstance.AuthLogin(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AnonymousApi.AuthLogin: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginModel**](LoginModel.md)| Login form data | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="authloginprovider"></a>
# **AuthLoginProvider**
> string AuthLoginProvider (LoginProviderModel body)

attempts a log in with provider details in post body

Uses the provider credentials specified in the post body and generates a login session if valid. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AuthLoginProviderExample
    {
        public void main()
        {
            
            var apiInstance = new AnonymousApi();
            var body = new LoginProviderModel(); // LoginProviderModel | Provider login data

            try
            {
                // attempts a log in with provider details in post body
                string result = apiInstance.AuthLoginProvider(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AnonymousApi.AuthLoginProvider: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginProviderModel**](LoginProviderModel.md)| Provider login data | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="usersregister"></a>
# **UsersRegister**
> string UsersRegister (RegisterModel body)

registers a user with the service

Validates the input posted and returns an auth token on successful registration. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UsersRegisterExample
    {
        public void main()
        {
            
            var apiInstance = new AnonymousApi();
            var body = new RegisterModel(); // RegisterModel | Registration form data

            try
            {
                // registers a user with the service
                string result = apiInstance.UsersRegister(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AnonymousApi.UsersRegister: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RegisterModel**](RegisterModel.md)| Registration form data | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

