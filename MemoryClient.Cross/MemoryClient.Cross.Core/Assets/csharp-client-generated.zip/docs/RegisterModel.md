# IO.Swagger.Model.RegisterModel
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | email address for new user | [optional] 
**Username** | **string** | username for new user login | [optional] 
**Password** | **string** | password for new account | [optional] 
**PasswordAgain** | **string** | password validation | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

